# LGMVIP-Web-Task2
It Contains Letsgrowmore internship task 2
